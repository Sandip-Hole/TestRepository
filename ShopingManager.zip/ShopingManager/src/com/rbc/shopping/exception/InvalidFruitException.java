package com.rbc.shopping.exception;

public class InvalidFruitException extends RuntimeException {
    public InvalidFruitException(String message) {
        super(message);
    }
}
